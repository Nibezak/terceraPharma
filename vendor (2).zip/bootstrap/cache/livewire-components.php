<?php return array (
  'admin.search-bar' => 'App\\Http\\Livewire\\Admin\\SearchBar',
  'attribute' => 'App\\Http\\Livewire\\Attribute',
  'footer-detail' => 'App\\Http\\Livewire\\FooterDetail',
  'nav-bar' => 'App\\Http\\Livewire\\NavBar',
  'search-dropdown' => 'App\\Http\\Livewire\\SearchDropdown',
);