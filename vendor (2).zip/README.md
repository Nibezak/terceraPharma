## This Project is ready for production. Its just plug & play.

### NB: You can use this eCommerce platform as long as you dont remove the footer copyrights. Using this project without copyright footer in production you will need to get commercial lisence.

## Tercera eCommerce Features

-   **[100% CMS]**
-   **[Social Login]**
-   **[Google Recaptcha]**
-   **[Data Visualisation]**
-   **[Real-time Search]**
-   **[Shopping cart]**
-   **[Product attributes]**
-   **[Product categories]**
-   **[Product sub categories]**
-   **[Product Multiple images]**
-   **[Multiple product uploads]**
-   **[System Settings]**
-   **[Image Sliders]**
-   **[Contact messaging]**
-   **[Tax options]**
-   **[Admin Area]**
-   **[Coupons & Discounts]**
-   **[SEO Settings]**
-   **[Dynamic Banners]**
-   **[Messaging System]**
-   **[Facebook Pixel Integration]**
-   **[Paypal Checkout]**
-   **[Payment on delivery]**
-   **[Social Links]**
-   **[Dynamic Terms & privacy policy]**

## Businesses using our solution

-   **[https://seamaf.com]**
-   **[https://vanessascakes.online]**

# License

**[Creative Commons Attribution 4.0 cc-by-4.0]**
