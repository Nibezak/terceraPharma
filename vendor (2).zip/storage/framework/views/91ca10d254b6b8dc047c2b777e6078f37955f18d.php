

<?php $__env->startSection('content'); ?>

<div class="card">
	<div class="card-header"><?php echo e(isset($slide) ? 'Update Slide' : 'Create Slide'); ?></div>
	<div class="card-body">
		<form action="<?php echo e(isset($slide) ? route('slides.update', $slide->id) : route('slides.store')); ?>" method="post" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<?php if(isset($slide)): ?>
				<?php echo method_field('PATCH'); ?>
			<?php endif; ?>

			<?php if(isset($slide)): ?>
				<div class="form-group">
					<img src="/storage/<?php echo e($slide->image); ?>" style="max-width: 60%; height: 300px;">
				</div>
			<?php endif; ?>
			<div class="form-group">
				<label for="image">Image Slider</label>
				<input type="file" name="image" id="image" class="form-control">
			</div>

			<div class="form-group">
				<label for="heading">Slider Heading</label>
				<input type="text" name="heading" id="heading" class="form-control" value="<?php echo e(isset($slide) ? $slide->heading : ''); ?>">
			</div>

			<div class="form-group">
				<label for="description">Slider Description</label>
				<input type="text" name="description" id="description" class="form-control" value="<?php echo e(isset($slide) ? $slide->description : ''); ?>">
			</div>

			<div class="form-group">
				<label for="link">Slider Link</label>
				<input type="text" name="link" id="link" class="form-control" value="<?php echo e(isset($slide) ? $slide->link : ''); ?>">
			</div>

			<div class="form-group">
				<button type="submit" class="btn btn-primary"><?php echo e(isset($slide) ? 'Update Slider' : 'Add Slider'); ?></button>
			</div>
		</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zimcart\resources\views/admin/slides/create.blade.php ENDPATH**/ ?>