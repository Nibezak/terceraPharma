

<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <nav area-label="breadcrumb">

        <ol class="breadcrumb">
            <a href="<?php echo e(route('home')); ?>" class="text-decoration-none mr-3">
                <li class="breadcrumb-item">Home</li>
            </a>
            <li class="breadcrumb-item active">Privacy Policy</li>
        </ol>

    </nav>

    <div class="card">
        <div class="card-header d-flex justify-content-between btn-sm">
            <span class="mt-2">
                <h4>Privacy Policy</h4>
            </span>
            <a href="<?php echo e(isset($policy) ? route('privacy.edit', $policy->id) : route('privacy.create')); ?>"
                class="btn btn-dark"><?php echo e(isset($policy) ? 'Edit Terms' : 'Add Terms'); ?></a>
        </div>

        <div class="card-body">
            <?php if(isset($policy)): ?>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="eg Tersera Privacy Policy"
                        value="<?php echo $policy->heading; ?>" readonly="">
                </div>
                <div><?php echo $policy->policy; ?></div>
            <?php else: ?>
                <div class="text-center">
                    <h3>Please add Privacy Policy to use services like Facebook login & Google login</h3>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zimcart\resources\views/admin/privacy/show.blade.php ENDPATH**/ ?>