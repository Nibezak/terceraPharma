

<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <nav area-label="breadcrumb">

        <ol class="breadcrumb">
            <a href="<?php echo e(route('home')); ?>" class="text-decoration-none mr-3">
                <li class="breadcrumb-item">Home</li>
            </a>
            <li class="breadcrumb-item active"><?php echo e($order->billing_fullname); ?>'s Order</li>
        </ol>

        <div class="card">
            <div class="card-header"><?php echo e($order->order_number); ?> <strong class="ml-5">Worth
                    rwf <?php echo e($order->billing_total); ?></strong></div>
            <div class="card-body">
                <h4>Products Ordered</h4>
                <table class="table table-bordered table-responsive table-dark">
                    <thead>
                        <th>Product Code</th>
                        <th>Product Name</th>
                        <th>Product Price</th>
                        <th>Product Qty</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($p->code); ?></td>
                                <td><?php echo e($p->name); ?></td>
                                <td><?php echo e($p->price); ?></td>
                                <td><?php echo e($p->pivot->quantity); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <h4>Customer Information</h4>
                <table class="table table-bordered table-responsive table-success">
                    <thead>
                        <th>Customer Name</th>
                        <th>Customer Phone</th>
                        <th>Customer Address</th>
                        <th>Customer City</th>
                        <th>Customer Transaction ID</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($order->billing_fullname); ?></td>
                            <td><?php echo e($order->billing_phone); ?></td>
                            <td><?php echo e($order->billing_address); ?></td>
                            <td><?php echo e($order->billing_city); ?></td>
                            <td><?php echo e($order->notes); ?></td>
                        </tr>
                    </tbody>
                </table>
                <h4>Order Status <strong class="text-capitalize text-danger"><?php echo e($order->status); ?></strong></h4>
                <form action="<?php echo e(route('orders.update', $order->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="form-group">
                        <label for="status">Update Order Status</label>
                        <select class="form-control" name="status">
                            <option class="text-capitalize" value="<?php echo e($order->status); ?>"><?php echo e($order->status); ?></option>
                            <option value="pending">Pending</option>
                            <option value="processing">Processing</option>
                            <option value="shipped">Shipped</option>
                            <option value="delivered">Delivered</option>
                            <option value="pending">Pending</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-danger">Update Status</button>
                    </div>
                </form>
            </div>
        </div>

    </nav>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zimcart\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>