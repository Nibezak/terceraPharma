

<?php $__env->startSection('content'); ?>

<!-- breadcrumb -->
<nav area-label="breadcrumb">

	<ol class="breadcrumb">
		<a href="<?php echo e(route('home')); ?>" class="text-decoration-none mr-3">
			<li class="breadcrumb-item">Home</li>
		</a>
		<li class="breadcrumb-item active">Coupons</li>
	</ol>
	
</nav>

<div class="card">
	<div class="card-header d-flex justify-content-between btn-sm">
		<span>Coupons</span>
		<a href="<?php echo e(route('coupon.create')); ?>" class="btn btn-dark">Add Coupons</a>
	</div>
	<div class="card-body">
		<table class="table table-dark table-bordered">
			<thead>
				<th>Type</th>
				<th>Code</th>
				<th>Value</th>
				<th>Edit</th>
				<th>Delete</th>
			</thead>
			<tbody>
				<?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr class="text-capitalize">
					<td> <?php echo e($coupon->type); ?> </td>
					<td> <?php echo e($coupon->code); ?> </td>
					<td> <?php echo e($coupon->value ?? $coupon->percent_off); ?> </td>
					<td>
						<a href="<?php echo e(route('coupon.edit', $coupon->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
					</td>
					<td>
						<form action="<?php echo e(route('coupon.destroy', $coupon->id)); ?>" method="post">
							<?php echo csrf_field(); ?>
							<?php echo method_field('DELETE'); ?>
							<button type="submit" class="btn btn-sm btn-danger">Delete</button>
						</form>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zimcart\resources\views/admin/coupons/index.blade.php ENDPATH**/ ?>