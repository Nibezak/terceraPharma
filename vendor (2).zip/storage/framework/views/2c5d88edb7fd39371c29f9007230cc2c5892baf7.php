

<?php $__env->startSection('content'); ?>

<!-- breadcrumb -->
<nav area-label="breadcrumb">

	<ol class="breadcrumb">
		<a href="<?php echo e(route('home')); ?>" class="text-decoration-none mr-3">
			<li class="breadcrumb-item">Home</li>
		</a>
		<li class="breadcrumb-item active">System Settings</li>
	</ol>
	
</nav>

<div class="card">
	<div class="card-header">System Settings</div>
	<div class="card-body">
		<table class="table table-dark table-bordered">
			<thead>
				<th>Name</th>
				<th>Logo</th>
				<th>Favicon</th>
				<th>Phone</th>
				<th>Email</th>
			</thead>
			<tbody>
				<tr>
					<td> <?php echo e($setting->name); ?> </td>
					<td> 
						<img src="/storage/<?php echo e($setting->logo); ?>" style="width: 81px; height: 22px;">
					</td>
					<td> 
						<img src="/storage/<?php echo e($setting->favicon); ?>" style="width: 40px; height: 40px; border-radius: 100%;">
					</td>
					<td> <?php echo e($setting->tel); ?> </td>
					<td> <?php echo e($setting->email); ?> </td>
					<td>
						<a href="<?php echo e(route('system-settings.edit', $setting->slug)); ?>" class="btn btn-primary">Edit</a>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zimcart\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>