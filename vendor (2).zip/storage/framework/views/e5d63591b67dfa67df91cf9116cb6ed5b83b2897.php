

<?php $__env->startSection('content'); ?>

<div class="card">
	<div class="card-header"> <?php echo e(isset($socialLinks) ? 'Update Links' : 'Add links'); ?> </div>
	<div class="card-body">
		<form action="<?php echo e(isset($socialLinks) ? route('social-links.update', $socialLinks->id) : route('social-links.store')); ?>" method="post">
			<?php echo csrf_field(); ?>
			<?php if(isset($socialLinks)): ?>
				<?php echo method_field('PATCH'); ?>
			<?php endif; ?>
			
			<div class="form-group">
				<label for="facebook">Facebook Page Link</label>
				<input type="text" name="facebook" id="facebook" class="form-control" value="<?php echo e(isset($socialLinks) ? $socialLinks->facebook : ''); ?>">
			</div>
			<div class="form-group">
				<label for="instagram">Instagram Page Link</label>
				<input type="text" name="instagram" id="instagram" class="form-control" value="<?php echo e(isset($socialLinks) ? $socialLinks->instagram : ''); ?>">
			</div>
			<div class="form-group">
				<label for="pinterest">Pinterest Page Link</label>
				<input type="text" name="pinterest" id="pinterest" class="form-control" value="<?php echo e(isset($socialLinks) ? $socialLinks->pinterest : ''); ?>">
			</div>
			<div class="form-group">
				<label for="linkedin">LinkedIn Page Link</label>
				<input type="text" name="linkedin" id="linkedin" class="form-control" value="<?php echo e(isset($socialLinks) ? $socialLinks->linkedin : ''); ?>">
			</div>
			<div class="form-group">
				<label for="youtube">Youtube Page Link</label>
				<input type="text" name="youtube" id="youtube" class="form-control" value="<?php echo e(isset($socialLinks) ? $socialLinks->youtube : ''); ?>">
			</div>
			<div class="form-group">
				<label for="twitter">Twitter Page Link</label>
				<input type="text" name="twitter" id="twitter" class="form-control" value="<?php echo e(isset($socialLinks) ? $socialLinks->twitter : ''); ?>">
			</div>
			<div class="form-group">
				<label for="tiktok">Tiktok Page Link</label>
				<input type="text" name="tiktok" id="tiktok" class="form-control" value="<?php echo e(isset($socialLinks) ? $socialLinks->tiktok : ''); ?>">
			</div>

			<div class="form-group">
				<button type="submit" class="btn btn-primary"><?php echo e(isset($socialLinks) ? 'Update Links' : 'Add links'); ?></button>
			</div>
		</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zimcart\resources\views/admin/social-links/create.blade.php ENDPATH**/ ?>