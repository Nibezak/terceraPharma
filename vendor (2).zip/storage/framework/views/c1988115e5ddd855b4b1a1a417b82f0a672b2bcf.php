

<?php $__env->startSection('seo'); ?>
    <title><?php echo e($systemInfo->name); ?> | Checkout</title>
    <meta charset="UTF-8">
    <meta name="description" content="<?php echo e($systemInfo->description); ?>">
    <meta name="keywords" content="<?php echo e($systemInfo->description); ?>, <?php echo e($systemInfo->description); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- checkout section  -->
    <section class="checkout-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 order-2 order-lg-1">
                    <form class="checkout-form" action="<?php echo e(route('checkout.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="cf-title">Billing Address</div>
                        <div class="row">
                            <div class="col-md-7">
                                <p>*Billing Information</p>
                            </div>
                            <div class="col-md-5">
                                <div class="cf-radio-btns address-rb">
                                    <div class="cfr-item">
                                        <input type="radio" name="pm" id="one">
                                        <label for="one">Use my regular address</label>
                                    </div>
                                    <div class="cfr-item">
                                        <input type="radio" name="pm" id="two">
                                        <label for="two">Use a different address</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row address-inputs">
                            <div class="col-md-6">
                                <input type="text" name="billing_fullname" placeholder="Full Name"
                                    value="<?php echo e(auth()->user()->name); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="billing_email" placeholder="Email"
                                    value="<?php echo e(auth()->user()->email); ?>">
                            </div>
                            <div class="col-md-12">
                                <input type="text" name="billing_address" placeholder="Address"
                                    value="<?php echo e(auth()->user()->address); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="billing_city" placeholder="City"
                                    value="<?php echo e(auth()->user()->city); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="billing_province" placeholder="Province or State"
                                    value="<?php echo e(auth()->user()->province); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="billing_zipcode" placeholder="Zip code"
                                    value="<?php echo e(auth()->user()->zipcode); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="billing_phone" placeholder="Phone no."
                                    value="<?php echo e(auth()->user()->phone); ?>">
                            </div>
                            <div class="col-md-12">
                                <input type="text" name="notes"
                                    placeholder="Input the MTN Momo Transaction Code e.g : SDK817900KDB"
                                    value="<?php echo e(auth()->user()->notes); ?>">
                            </div>
                        </div>
                        
                        
                        <div class="cf-title">Payment</div>
                        <ul class="payment-list">
                            
                            

                            <li>
                                <input type="radio" name="payment_method" value="momo">
                                MTN Momo<a href="#"><img src="<?php echo e(asset('frontend/img/mtnlogo.png')); ?>" alt=""
                                        width="50" height="50"></a>
                            </li>
                            
                            
                            <li>
                                <input type="radio" name="payment_method" value="cash_on_delivery">
                                Pay when you get the package
                            </li>

                        </ul>
                        <button type="submit" class="site-btn submit-order-btn">Place Order</button>
                    </form>
                </div>
                <div class="col-lg-4 order-1 order-lg-2">
                    <div class="checkout-cart">
                        <h3>Your Cart</h3>
                        <ul class="product-list">
                            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div class="pl-thumb">
                                        <?php if($item->model->photos->count() > 0): ?>
                                            <img src="/storage/<?php echo e($item->model->photos->first()->images); ?>" alt="">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('frontend/img/no-image.png')); ?>" alt="">
                                        <?php endif; ?>
                                    </div>
                                    <h6><?php echo e($item->model->name); ?></h6>
                                    <p>rwf <?php echo e($item->subtotal); ?></p>
                                    <p>Qty <?php echo e($item->qty); ?></p>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <ul class="price-list">
                            <li>Total<span>rwf <?php echo e($newSubtotal); ?>.00</span></li>
                            <li class="total">Total<span>rwf <?php echo e($newTotal); ?>.00</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- checkout section end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zimcart\resources\views/checkout.blade.php ENDPATH**/ ?>