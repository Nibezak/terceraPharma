

<?php $__env->startSection('seo'); ?>

<title><?php echo e(auth()->user()->name); ?> 's | Profile</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<!-- Category section -->
	
	<!-- Category section end -->

	<div class="card col-lg col-xl-9 flex-row mx-auto px-0">
		<div class="card-body">
			<h4 class="title text-center mt-2 mb-3">Edit your account</h4>
			<form class="form-box px-3"method="POST" action="<?php echo e(route('my-profile.store')); ?>">
	            <?php echo csrf_field(); ?>
	            <div class="form-input">
	                <span><i class="fa fa-user"></i></span>
	                <input type="text" name="name" placeholder="Name" tabindex="10" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(auth()->user()->name ?? old('name')); ?>" required>

	                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                    <span class="invalid-feedback mt-3" role="alert">
	                        <strong><?php echo e($message); ?></strong>
	                    </span>
	                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	            </div>
	            <div class="form-input">
	                <span><i class="fa fa-envelope"></i></span>
	                <input type="email" name="email" placeholder="Email Address" tabindex="10" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(auth()->user()->email ?? old('email')); ?>" required>

	                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                    <span class="invalid-feedback mt-3" role="alert">
	                        <strong><?php echo e($message); ?></strong>
	                    </span>
	                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	            </div>
	            <div class="form-input">
	                <span><i class="fa fa-key"></i></span>
	                <input type="password" name="password"class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  placeholder="Password">

	                 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                    <span class="invalid-feedback mt-3" role="alert">
	                        <strong><?php echo e($message); ?></strong>
	                    </span>
	                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	            </div>
	            <div class="form-input">
	                <span><i class="fa fa-key"></i></span>
	                <input type="password" name="password_confirmation" placeholder="Confirm Password" class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

	                 <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                    <span class="invalid-feedback mt-3" role="alert">
	                        <strong><?php echo e($message); ?></strong>
	                    </span>
	                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	            </div>
	            <div class="mb-3">
	                <button type="submit" class="btn btn-block">Submit Profile Changes</button>
	            </div>
	        </form>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zimcart\resources\views/profile/edit.blade.php ENDPATH**/ ?>