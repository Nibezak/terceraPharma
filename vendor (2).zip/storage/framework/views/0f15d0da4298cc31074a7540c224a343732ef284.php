

<?php $__env->startSection('content'); ?>
<!-- breadcrumb -->
<nav area-label="breadcrumb">

	<ol class="breadcrumb">
		<a href="<?php echo e(route('home')); ?>" class="text-decoration-none mr-3">
			<li class="breadcrumb-item">Home</li>
		</a>
		<li class="breadcrumb-item active">Messages</li>
	</ol>
	
</nav>

<!-- Dispaly all products from DB -->
<div class="card">
	<div class="card-header d-flex justify-content-between">
		<span>Messages</span>
	</div>
	<div class="card-body">
		<table class="table table-dark table-bordered table-responsive">
			<thead>
				<th>Name</th>
				<th>Email</th>
				<th>Subject</th>
				<th>Time</th>
				<th>Read</th> 
			</thead>
			<tbody>
				<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($message->name); ?></td>
					<td><?php echo e($message->email); ?></td>
					<td><?php echo e($message->subject); ?></td>
					<td><?php echo e($message->created_at->diffForHumans()); ?></td>
					<td>
						<a href="<?php echo e(route('contact.show', $message->id)); ?>">
							<button class="btn btn-success btn-sm">Read Message</button>
						</a>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zimcart\resources\views/admin/messages/index.blade.php ENDPATH**/ ?>