<!DOCTYPE html>
<html lang="zxx"> 
<head>
	<?php echo $__env->yieldContent('seo'); ?>
	<!-- Favicon -->
	<link href="/storage/<?php echo e($shareSettings->favicon); ?>" rel="shortcut icon"/>

	<!-- Google Font -->
	<link href="https://fonts.googleapis.com/css?family=Josefin+Sans:300,300i,400,400i,700,700i" rel="stylesheet">


	<!-- Stylesheets -->
	<link rel="stylesheet" href="<?php echo e(asset('frontend/css/all.css')); ?>"/>

	<link rel="stylesheet" href="<?php echo e(asset('css/toastr.min.css')); ?>"/>
	<!-- font-owesome icons link -->
    <link href="<?php echo e(asset('frontend/fontawesome/css/all.css')); ?>" rel="stylesheet">

	<?php echo \Livewire\Livewire::styles(); ?>

	<?php echo $__env->yieldContent('css'); ?>

	<!-- Global site tag (gtag.js) - Google Analytics -->
	<?php if($shareSettings->google_analytics != null): ?>
	<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo e($shareSettings->google_analytics); ?>"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', '<?php echo e($shareSettings->google_analytics); ?>');
	</script>
	<?php endif; ?>

</head>
<body>
	
	<!-- Header section -->
	<header class="header-section">
		<div class="header-top">
			<div class="container">
				<div class="row">
					<div class="col-lg-2 text-center text-lg-left">
						<!-- logo -->
						<a href="/" class="site-logo">
							<img src="/storage/<?php echo e($shareSettings->logo); ?>" alt="">
						</a>
					</div>
					<!-- search area -->
					<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search-dropdown', [])->html();
} elseif ($_instance->childHasBeenRendered('svW4zkj')) {
    $componentId = $_instance->getRenderedChildComponentId('svW4zkj');
    $componentTag = $_instance->getRenderedChildComponentTagName('svW4zkj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('svW4zkj');
} else {
    $response = \Livewire\Livewire::mount('search-dropdown', []);
    $html = $response->html();
    $_instance->logRenderedChild('svW4zkj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
					<div class="col-xl-4 col-lg-5">
						<div class="user-panel">
							<div class="up-item">
								<div class="shopping-card">
									<i class="flaticon-heart"></i>
									<?php if(Cart::instance('wishlist')->count() != 0): ?>
										<span><?php echo e(Cart::instance('wishlist')->count()); ?></span>
									<?php endif; ?>
								</div>
								<a href="<?php echo e(route('wishlist.index')); ?>">Wishlist</a>
							</div>
							<div class="up-item">
								<div class="shopping-card">
									<i class="flaticon-bag"></i>
									<span><?php echo e(Cart::instance('default')->count()); ?></span>
								</div>
								<a href="<?php echo e(route('cart.index')); ?>">Shopping Cart</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('nav-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l8Gdshj')) {
    $componentId = $_instance->getRenderedChildComponentId('l8Gdshj');
    $componentTag = $_instance->getRenderedChildComponentTagName('l8Gdshj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l8Gdshj');
} else {
    $response = \Livewire\Livewire::mount('nav-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l8Gdshj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
	</header>
	<!-- Header section end -->

	<?php echo $__env->yieldContent('content'); ?>


	<!-- Footer section -->
	<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('footer-detail', [])->html();
} elseif ($_instance->childHasBeenRendered('sJiIzdD')) {
    $componentId = $_instance->getRenderedChildComponentId('sJiIzdD');
    $componentTag = $_instance->getRenderedChildComponentTagName('sJiIzdD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sJiIzdD');
} else {
    $response = \Livewire\Livewire::mount('footer-detail', []);
    $html = $response->html();
    $_instance->logRenderedChild('sJiIzdD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
	<!-- Footer section end -->



	<!--====== Javascripts & Jquery ======-->
	<?php echo \Livewire\Livewire::scripts(); ?>

	<script src="<?php echo e(asset('frontend/js/all.js')); ?>"></script>

	<script src="<?php echo e(asset('js/toastr.js')); ?>"></script>
	<script>
	    <?php if(Session::has('success')): ?>
	    toastr.success("<?php echo e(Session::get('success')); ?>")
	    <?php endif; ?>
	</script>

	<script>
	    <?php if(Session::has('error')): ?>
	    toastr.error("<?php echo e(Session::get('error')); ?>")
	    <?php endif; ?>
	</script>

	<?php echo $__env->yieldContent('scripts'); ?>

	</body>
</html>
<?php /**PATH C:\laragon\www\zimcart\resources\views/layouts/frontend.blade.php ENDPATH**/ ?>