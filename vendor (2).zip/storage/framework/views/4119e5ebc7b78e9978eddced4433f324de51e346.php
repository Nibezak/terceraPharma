

<?php $__env->startSection('content'); ?>


<div class="card">
	<div class="card-header">System Settings</div>
	<div class="card-body">
		<form action="<?php echo e(route('system-settings.update', $setting->slug)); ?>" method="post" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<?php echo method_field('PATCH'); ?>
			<!-- Company name -->
			<div class="form-group">
				<label for="name">Comapny Name</label>
				<input type="text" name="name" id="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($setting->name); ?>">

				<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<span class="invalid-feedback" role="alert">
						<strong> <?php echo e($message); ?> </strong>
					</span>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<!-- Company logo -->
			<?php if(isset($setting)): ?>
				<img src="/storage/<?php echo e($setting->logo); ?>" style="width: 162px; height: 55px;">
			<?php endif; ?>
			<div class="form-group">
				<label for="logo">Company Logo</label>
				<input type="file" name="logo" id="logo" class="form-control <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($setting->name); ?>">

				<?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<span class="invalid-feedback" role="alert">
						<strong> <?php echo e($message); ?> </strong>
					</span>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<!-- Company favicon -->
			<?php if(isset($setting)): ?>
				<img src="/storage/<?php echo e($setting->favicon); ?>" style="width: 128px; height: 128px;">
			<?php endif; ?>
			<div class="form-group">
				<label for="favicon">Company Favicon</label>
				<input type="file" name="favicon" id="favicon" class="form-control <?php $__errorArgs = ['favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($setting->name); ?>">

				<?php $__errorArgs = ['favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<span class="invalid-feedback" role="alert">
						<strong> <?php echo e($message); ?> </strong>
					</span>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>		
			<!-- Company description -->
			<div class="form-group">
				<label for="description">Company Description</label>
				<textarea type="text" name="description" id="description" class="form-control"><?php echo e($setting->description); ?></textarea>
			</div>
			<!-- Company address -->
			<div class="form-group">
				<label for="address">Company Address</label>
				<input type="text" name="address" id="address" class="form-control" value="<?php echo e($setting->address); ?>">
			</div>
			<!-- Company tel -->	
			<div class="form-group">
				<label for="tel">Company Phone</label>
				<input type="tel" name="tel" id="tel" class="form-control" value="<?php echo e($setting->tel); ?>">
			</div>
			<!-- Company eamil -->
			<div class="form-group">
				<label for="email">Company Email</label>
				<input type="email" name="email" id="email" class="form-control" value="<?php echo e($setting->email); ?>">
			</div>

			<!-- system seo start -->
			<div class="form-group">
				<label for="meta_description">System Meta Description</label>
				<textarea name="meta_description" class="form-control" placeholder="Make your web application visible on search engine by describing what you do..."><?php echo e($setting->meta_description); ?></textarea>
			</div>
			<div class="form-group">
				<label for="meta_keywords">System Meta Keywords</label>
				<input name="meta_keywords" class="form-control" placeholder="Seperate keywords using comma..." value="<?php echo e($setting->meta_keywords); ?>">
			</div>
			<div class="form-group">
				<label for="facebook_pixel">Facebook Pixel</label>
				<input name="facebook_pixel" class="form-control" placeholder="Your Facebook Pixel ID eg AC-162735780-5" value="<?php echo e($setting->facebook_pixel); ?>">
			</div>
			<div class="form-group">
				<label for="google_analytics">Google Analytics</label>
				<input name="google_analytics" class="form-control" placeholder="Your Google Analytics ID eg AC-162735780-5" value="<?php echo e($setting->google_analytics); ?>">
			</div>
			<!-- system seo start -->

			<div class="form-group">
				<button type="submit" class="btn btn-primary">Update Details</button>
			</div>
		</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zimcart\resources\views/admin/settings/edit.blade.php ENDPATH**/ ?>