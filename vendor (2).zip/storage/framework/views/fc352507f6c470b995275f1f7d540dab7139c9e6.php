

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/trix.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header"><?php echo e(isset($policy) ? 'Update Privacy Policy' : 'Add Privacy Policy'); ?></div>
        <div class="card-body">
            <form action="<?php echo e(isset($policy) ? route('privacy.update', $policy->id) : route('privacy.store')); ?>"
                method="post">
                <?php echo csrf_field(); ?>
                <?php if(isset($policy)): ?>
                    <?php echo method_field('PATCH'); ?>
                <?php endif; ?>
                <div class="form-group">
                    <label for="Heading">Heading</label>
                    <input type="text" name="heading" class="form-control" placeholder="eg Tersera Privacy Policy"
                        value="<?php echo e(isset($policy) ? $policy->heading : ''); ?>">
                </div>

                <div class="form-group">
                    <label for="policy">Privacy Policy</label>
                    <input name="policy" type="hidden" id="policy" rows="10" class="form-control"
                        value="<?php echo e(isset($policy) ? $policy->policy : ''); ?>">
                    <trix-editor input="policy"></trix-editor>
                </div>

                <div class="form-group">
                    <button type="submit"
                        class="btn btn-primary"><?php echo e(isset($policy) ? 'Update Privacy Policy' : 'Add Privacy Policy'); ?></button>
                </div>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/trix.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zimcart\resources\views/admin/privacy/create.blade.php ENDPATH**/ ?>