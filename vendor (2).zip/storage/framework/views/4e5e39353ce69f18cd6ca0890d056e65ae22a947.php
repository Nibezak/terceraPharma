

<?php $__env->startSection('seo'); ?>
    <title>
        <?php if(auth()->check()): ?>
            <?php echo e(auth()->user()->name); ?> 's Orders
        <?php endif; ?>
    </title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- cart section end -->
    <section class="cart-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="cart-table">
                        <h3>My Orders</h3>
                        <div class="cart-table-warp">
                            <table>
                                <thead>
                                    <tr>
                                        <th class="size-col">Order Number</th>
                                        <th class="size-col">Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="size-col">
                                                <h4><?php echo e($order->order_number); ?></h4>
                                            </td>
                                            <td class="total-col">
                                                <h4>rwf <?php echo e($order->billing_total); ?></h4>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('my-profile.show', $order->id)); ?>"
                                                    class="btn btn-success btn-sm">View Order</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="ml-3">
                                <?php echo e($orders->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 card-right">
                    <a href="<?php echo e(route('my-profile.edit')); ?>" class="site-btn">Profile Settings</a>
                    <a href="<?php echo e(route('frontendCategories')); ?>" class="site-btn sb-dark">Continue shopping</a>
                </div>
            </div>
        </div>
    </section>
    <!-- cart section end -->

    <!-- Related product section -->
    <section class="related-product-section">
        <div class="container">
            <div class="section-title text-uppercase">
                <h2>You Also Viewed</h2>
            </div>
            <div class="row">
                <?php $__currentLoopData = $recentlyViewed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-sm-6">
                        <div class="product-item">
                            <div class="pi-pic">
                                <div class="tag-new">New</div>
                                <a href="<?php echo e(route('single-product', $view->slug)); ?>">
                                    <?php if($view->photos->count() > 0): ?>
                                        <img src="/storage/<?php echo e($view->photos->first()->images); ?>" alt="">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('frontend/img/no-image.png')); ?>" alt="">
                                    <?php endif; ?>
                                </a>
                                <div class="pi-links">
                                    <form action="<?php echo e(route('cart.store')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($view->id); ?>">
                                        <input type="hidden" name="name" value="<?php echo e($view->name); ?>">
                                        <input type="hidden" name="price" value="<?php echo e($view->price); ?>">
                                        <input type="hidden" name="quantity" value="1">
                                        <button type="submit" class="add-card"><i class="flaticon-bag"></i><span>ADD TO
                                                CART</span></button>
                                    </form>
                                    <form>
                                        <button type="submit" class="wishlist-btn"><i class="flaticon-heart"></i></button>
                                    </form>
                                </div>
                            </div>
                            <div class="pi-text">
                                <h6>rwf <?php echo e($view->price); ?></h6>
                                <p><?php echo e($view->name); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Related product section end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zimcart\resources\views/profile/index.blade.php ENDPATH**/ ?>